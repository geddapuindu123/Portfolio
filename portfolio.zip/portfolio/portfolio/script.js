// Update the scroll event to toggle a class on the navigation bar when scrolling
const nav = document.querySelector('nav');

window.addEventListener('scroll', () => {
    nav.classList.toggle('naWinScroll', window.scrollY > 0);
});

// Typewriter effect for rotating names
const names = ["Web Development", "Frontend Development"];
let currentNameIndex = 0;
let currentLetterIndex = 0;
const nameElement = document.getElementById('name');

function typeName() {
    if (currentLetterIndex < names[currentNameIndex].length) {
        nameElement.textContent += names[currentNameIndex].charAt(currentLetterIndex);
        currentLetterIndex++;
        setTimeout(typeName, 150); // Adjust typing speed here
    } else {
        setTimeout(eraseName, 1000); // Delay before erasing starts
    }
}

function eraseName() {
    if (currentLetterIndex > 0) {
        nameElement.textContent = nameElement.textContent.slice(0, -1);
        currentLetterIndex--;
        setTimeout(eraseName, 100); // Adjust erasing speed here
    } else {
        currentNameIndex = (currentNameIndex + 1) % names.length;
        setTimeout(typeName, 500); // Start typing the next name
    }
}

// Start the typewriter effect
typeName();

// Handle form submission
document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Here you can add custom validation or logic

    // Show a loading message or animation (optional)
    // ...

    // Example of a success message
    alert('Thank you for your message! We will get back to you soon.');

    // Optionally, you can reset the form
    this.reset();

    // Optionally, redirect to a thank you page or update UI
});
